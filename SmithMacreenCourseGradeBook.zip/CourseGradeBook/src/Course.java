import java.util.ArrayList;

public class Course {

    private ArrayList<Student> listAllStudents;

    public Course(){
       listAllStudents = new ArrayList<Student>();
        //
    }
    public void Add(Student st){
        listAllStudents.add(st);
    }

    public void numberedList() {
        //  numberedList();numberedList=
        for (int i = 0; i < listAllStudents.size(); i++) {
            System.out.println(listAllStudents.get(i));
            }
        }
        // use i for loop, I goes to 0 to size. use i.
    public void findStudentByName(String nickname){
        boolean check = true;
        for(int i = 0; i <listAllStudents.size(); i++) {
            if (nickname.equals(listAllStudents.get(i).getName())) {
                check = false;
                System.out.println(listAllStudents.get(i));
            }
        }
        if(check){
            System.out.println("There are no students that meets this requirement.");
        }
            }

    public void findAllStudentAboveGrade(int gpa) {
        boolean test = true;
        for(int i = 0; i <listAllStudents.size(); i++){
            if(gpa < listAllStudents.get(i).getGrade()) {
                test = false;
                System.out.println(listAllStudents.get(i));
            }
            if(test){
                System.out.println("Invalid Input.");
            }
        }
    }
    }
    //make a method in the course class that takes in a student, and adds it to the array list: ListAllStudents.

